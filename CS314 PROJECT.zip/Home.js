function displayJobMessage() {
  alert('Welcome to JobMatch!');
}

window.onload = function() {
  displayJobMessage();
}