<?php

$servername = "localhost";  
$username = "root";     
$password = "";      
$dbname = "myDB";  


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $companyName = $_POST["companyName"];
    $companyAddress = $_POST["companyAddress"];
    $phoneNumber = $_POST["phoneNumber"];
    $email = $_POST["email"];
    $website = $_POST["website"];
    $employment = $_POST["employment"];
    $establishmentDate = $_POST["establishmentDate"];
    $vision = $_POST["vision"];
    $coreValues = $_POST["coreValues"];
    $jobAdvertisement = $_POST["jobAdvertisement"];
    $jobDescription = $_POST["jobDescription"];

    
    $sql = "INSERT INTO job (companyName, companyAddress, phoneNumber, email, website, employment, establishmentDate, vision, coreValues, jobAdvertisement, jobDescription)
            VALUES ('$companyName', '$companyAddress', '$phoneNumber', '$email', '$website', '$employment', '$establishmentDate', '$vision', '$coreValues', '$jobAdvertisement', '$jobDescription')";

    if ($conn->query($sql) === TRUE) {
        $response = array("status" => "success", "message" => "Your data inserted successfully");
    } else {
        $response = array("status" => "error", "message" => "Error inserting data: " . $conn->error);
    }

    
    header("Content-Type: application/json");
    echo json_encode($response);
} else {
    
    $response = array("status" => "error", "message" => "Invalid request method");
    echo json_encode($response);
}


$conn->close();
?>
